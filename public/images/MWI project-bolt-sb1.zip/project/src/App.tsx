import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Services from './components/Services';
import WhyChooseUs from './components/WhyChooseUs';
import Vision from './components/Vision';
import CoreFocusValues from './components/CoreFocusValues';
import FAQ from './components/FAQ';
import Contact from './components/Contact';
import Footer from './components/Footer';
import StickyMobileFooter from './components/StickyMobileFooter';

function App() {
  return (
    <div className="min-h-screen">
      <Header />
      <Hero />
      <Services />
      <WhyChooseUs />
      <Vision />
      <CoreFocusValues />
      <FAQ />
      <Contact />
      <Footer />
      <StickyMobileFooter />
    </div>
  );
}

export default App;