import React, { useState } from 'react';
import { Target, Heart, ChevronDown, ChevronUp } from 'lucide-react';

const CoreFocusValues = () => {
  const [activeAccordion, setActiveAccordion] = useState<string | null>(null);

  const toggleAccordion = (section: string) => {
    setActiveAccordion(activeAccordion === section ? null : section);
  };

  return (
    <section className="py-12 md:py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Core Focus */}
          <div className="space-y-4 md:space-y-6">
            <div className="flex items-center gap-4 mb-8">
              <div className="bg-[#FF6606] rounded-full p-4">
                <Target className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-3xl lg:text-4xl font-bold text-[#604C45]">
                Core Focus
              </h2>
            </div>

            <div className="space-y-3 md:space-y-4">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <button
                  onClick={() => toggleAccordion('why-exist')}
                  className="w-full px-4 md:px-6 py-3 md:py-4 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
                >
                  <span className="text-sm md:text-base font-semibold text-[#604C45]">Why we exist</span>
                  {activeAccordion === 'why-exist' ? 
                    <ChevronUp className="text-[#FF6606]" /> : 
                    <ChevronDown className="text-[#FF6606]" />
                  }
                </button>
                {activeAccordion === 'why-exist' && (
                  <div className="px-4 md:px-6 pb-3 md:pb-4 text-sm md:text-base text-gray-600">
                    To provide innovative, compassionate mental health care that transforms lives and strengthens communities across South Dakota and Iowa.
                  </div>
                )}
              </div>

              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <button
                  onClick={() => toggleAccordion('contracted-services')}
                  className="w-full px-4 md:px-6 py-3 md:py-4 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
                >
                  <span className="text-sm md:text-base font-semibold text-[#604C45]">Contracted Mental Health Services</span>
                  {activeAccordion === 'contracted-services' ? 
                    <ChevronUp className="text-[#FF6606]" /> : 
                    <ChevronDown className="text-[#FF6606]" />
                  }
                </button>
                {activeAccordion === 'contracted-services' && (
                  <div className="px-4 md:px-6 pb-3 md:pb-4 text-sm md:text-base text-gray-600">
                    Contracted mental health services provided through trust-based partnerships with healthcare systems, ensuring seamless integration and continuity of care.
                  </div>
                )}
              </div>

              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <button
                  onClick={() => toggleAccordion('independent-evaluations')}
                  className="w-full px-4 md:px-6 py-3 md:py-4 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
                >
                  <span className="text-sm md:text-base font-semibold text-[#604C45]">Independent Psychiatric Evaluations</span>
                  {activeAccordion === 'independent-evaluations' ? 
                    <ChevronUp className="text-[#FF6606]" /> : 
                    <ChevronDown className="text-[#FF6606]" />
                  }
                </button>
                {activeAccordion === 'independent-evaluations' && (
                  <div className="px-4 md:px-6 pb-3 md:pb-4 text-sm md:text-base text-gray-600">
                    Comprehensive, unbiased psychiatric evaluations for legal, disability, and clinical purposes, conducted by board-certified psychiatrists.
                  </div>
                )}
              </div>

              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <button
                  onClick={() => toggleAccordion('clinic-services')}
                  className="w-full px-4 md:px-6 py-3 md:py-4 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
                >
                  <span className="text-sm md:text-base font-semibold text-[#604C45]">Psychiatric Clinic Services</span>
                  {activeAccordion === 'clinic-services' ? 
                    <ChevronUp className="text-[#FF6606]" /> : 
                    <ChevronDown className="text-[#FF6606]" />
                  }
                </button>
                {activeAccordion === 'clinic-services' && (
                  <div className="px-4 md:px-6 pb-3 md:pb-4 text-sm md:text-base text-gray-600">
                    Full-service psychiatric clinic offering medication management, therapy, and specialized treatments in comfortable, welcoming environments.
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Core Values */}
          <div className="space-y-4 md:space-y-6">
            <div className="flex items-center gap-4 mb-8">
              <div className="bg-[#88A36C] rounded-full p-4">
                <Heart className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-3xl lg:text-4xl font-bold text-[#604C45]">
                Core Values
              </h2>
            </div>

            <div className="space-y-3 md:space-y-4">
              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <button
                  onClick={() => toggleAccordion('our-beliefs')}
                  className="w-full px-4 md:px-6 py-3 md:py-4 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
                >
                  <span className="text-sm md:text-base font-semibold text-[#604C45]">Our beliefs</span>
                  {activeAccordion === 'our-beliefs' ? 
                    <ChevronUp className="text-[#88A36C]" /> : 
                    <ChevronDown className="text-[#88A36C]" />
                  }
                </button>
                {activeAccordion === 'our-beliefs' && (
                  <div className="px-4 md:px-6 pb-3 md:pb-4 text-sm md:text-base text-gray-600">
                    We believe in the inherent dignity and worth of every individual, and that mental health is fundamental to overall well-being and quality of life.
                  </div>
                )}
              </div>

              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <button
                  onClick={() => toggleAccordion('trust-partnerships')}
                  className="w-full px-4 md:px-6 py-3 md:py-4 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
                >
                  <span className="text-sm md:text-base font-semibold text-[#604C45]">Trust-Based Partnerships</span>
                  {activeAccordion === 'trust-partnerships' ? 
                    <ChevronUp className="text-[#88A36C]" /> : 
                    <ChevronDown className="text-[#88A36C]" />
                  }
                </button>
                {activeAccordion === 'trust-partnerships' && (
                  <div className="px-4 md:px-6 pb-3 md:pb-4 text-sm md:text-base text-gray-600">
                    Building lasting relationships founded on trust, transparency, and mutual respect with patients, families, and healthcare partners.
                  </div>
                )}
              </div>

              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <button
                  onClick={() => toggleAccordion('evidence-based')}
                  className="w-full px-4 md:px-6 py-3 md:py-4 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
                >
                  <span className="text-sm md:text-base font-semibold text-[#604C45]">Evidence-Based Excellence</span>
                  {activeAccordion === 'evidence-based' ? 
                    <ChevronUp className="text-[#88A36C]" /> : 
                    <ChevronDown className="text-[#88A36C]" />
                  }
                </button>
                {activeAccordion === 'evidence-based' && (
                  <div className="px-4 md:px-6 pb-3 md:pb-4 text-sm md:text-base text-gray-600">
                    Commitment to using scientifically proven treatments and continuously improving our services through research and professional development.
                  </div>
                )}
              </div>

              <div className="bg-white rounded-lg shadow-md overflow-hidden">
                <button
                  onClick={() => toggleAccordion('compassionate-care')}
                  className="w-full px-4 md:px-6 py-3 md:py-4 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
                >
                  <span className="text-sm md:text-base font-semibold text-[#604C45]">Compassionate Care</span>
                  {activeAccordion === 'compassionate-care' ? 
                    <ChevronUp className="text-[#88A36C]" /> : 
                    <ChevronDown className="text-[#88A36C]" />
                  }
                </button>
                {activeAccordion === 'compassionate-care' && (
                  <div className="px-4 md:px-6 pb-3 md:pb-4 text-sm md:text-base text-gray-600">
                    Providing empathetic, patient-centered care that honors each person's unique journey and promotes healing in a safe, supportive environment.
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CoreFocusValues;