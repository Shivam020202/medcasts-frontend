import React, { useState } from 'react';
import { ArrowRight, CheckCircle } from 'lucide-react';
import PopupForm from './PopupForm';

const Hero = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    phone: ''
  });
  const [showSuccess, setShowSuccess] = useState(false);
  const [showPopup, setShowPopup] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
    setFormData({ fullName: '', email: '', phone: '' });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <section className="relative min-h-screen bg-gradient-to-br from-gray-50 to-white overflow-hidden pt-20">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-10 w-72 h-72 bg-[#FF6606] rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#88A36C] rounded-full blur-3xl"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 md:pt-16 pb-8 md:pb-16">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Side - Content */}
          <div className="space-y-8">
            <div className="space-y-4 md:space-y-6">
              <h1 className="text-5xl lg:text-6xl font-bold text-[#604C45] leading-tight">
                Finding Innovative Ways to{' '}
                <span className="text-[#FF6606]">Improve Lives</span>
              </h1>
              <p className="text-lg md:text-xl text-gray-600 leading-relaxed max-w-2xl">
                Expert mental health care for all ages in South Dakota & Iowa. 
                Compassionate, evidence-based treatment tailored to your unique needs.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 md:gap-4">
              <button 
                onClick={() => setShowPopup(true)}
                className="group bg-[#FF6606] text-white px-8 py-4 rounded-lg hover:bg-[#88A36C] transition-all duration-300 transform hover:scale-105 font-semibold text-lg flex items-center justify-center gap-2"
              >
                Book a Consultation
                <ArrowRight className="group-hover:translate-x-1 transition-transform" size={20} />
              </button>
            </div>

            {/* Trust Indicators */}
            <div className="flex flex-wrap gap-4 md:gap-6 pt-6 md:pt-8 border-t border-gray-200">
              <div className="flex items-center gap-2">
                <CheckCircle className="text-[#88A36C]" size={20} />
                <span className="text-gray-600">Insurance Accepted</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="text-[#88A36C]" size={20} />
                <span className="text-gray-600">Immediate Availability</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="text-[#88A36C]" size={20} />
                <span className="text-gray-600">Research-Based Treatments</span>
              </div>
            </div>
          </div>

          {/* Right Side - Form */}
          <div className="relative">
            <div className="bg-white rounded-2xl shadow-2xl p-6 md:p-8 border border-gray-100">
              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-[#604C45] mb-2">Get Started Today</h3>
                <p className="text-gray-600">Schedule your consultation with our experts</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4 md:space-y-6">
                <div>
                  <label htmlFor="fullName" className="block text-sm font-medium text-[#604C45] mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    id="fullName"
                    name="fullName"
                    value={formData.fullName}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6606] focus:border-transparent transition-all duration-200"
                    placeholder="Enter your full name"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-[#604C45] mb-2">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6606] focus:border-transparent transition-all duration-200"
                    placeholder="Enter your email"
                  />
                </div>

                <div>
                  <label htmlFor="phone" className="block text-sm font-medium text-[#604C45] mb-2">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6606] focus:border-transparent transition-all duration-200"
                    placeholder="Enter your phone number"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#FF6606] text-white py-3 md:py-4 rounded-lg hover:bg-[#88A36C] transition-all duration-300 transform hover:scale-105 font-semibold text-lg"
                >
                  Schedule Consultation
                </button>
              </form>

              <p className="text-xs text-gray-500 text-center mt-3 md:mt-4">
                By submitting this form, you agree to our privacy policy and terms of service.
              </p>
            </div>

            {/* Success Modal */}
            {showSuccess && (
              <div className="absolute inset-0 bg-white bg-opacity-95 rounded-2xl flex items-center justify-center">
                <div className="text-center">
                  <CheckCircle className="text-[#88A36C] mx-auto mb-4" size={48} />
                  <h4 className="text-xl font-bold text-[#604C45] mb-2">Thank You!</h4>
                  <p className="text-gray-600">We'll contact you within 24 hours to schedule your consultation.</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      
      <PopupForm 
        isOpen={showPopup} 
        onClose={() => setShowPopup(false)}
        title="Book Your Consultation"
      />
    </section>
  );
};

export default Hero;