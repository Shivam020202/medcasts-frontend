import React from 'react';
import { Brain, Zap, UserCheck, Pill, MessageCircle, Shield, Scale, Heart } from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: <Brain className="w-12 h-12" />,
      title: "TMS Therapy"
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Spravato® Treatment"
    },
    {
      icon: <UserCheck className="w-8 h-8" />,
      title: "Psychiatric Evaluations"
    },
    {
      icon: <Pill className="w-8 h-8" />,
      title: "Medication Management"
    },
    {
      icon: <MessageCircle className="w-8 h-8" />,
      title: "Psychotherapy"
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Suboxone & Naltrexone"
    },
    {
      icon: <Scale className="w-8 h-8" />,
      title: "Forensic Evaluations"
    },
    {
      icon: <Heart className="w-8 h-8" />,
      title: "Veteran Services"
    }
  ];

  return (
    <section id="services" className="py-12 md:py-16 bg-[#604C45]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 md:mb-12">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4 md:mb-6">
            Our <span className="text-[#FF6606]">Services</span>
          </h2>
          <p className="text-lg md:text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
            Comprehensive mental health services tailored to meet your unique needs with evidence-based treatments and compassionate care.
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white rounded-xl p-4 md:p-6 text-center hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 group cursor-pointer"
            >
              <div className="text-[#FF6606] mb-3 md:mb-4 flex justify-center group-hover:scale-110 transition-transform duration-300">
                {service.icon}
              </div>
              <h3 className="text-sm md:text-base lg:text-lg font-semibold text-[#604C45] group-hover:text-[#FF6606] transition-colors leading-tight">
                {service.title}
              </h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;