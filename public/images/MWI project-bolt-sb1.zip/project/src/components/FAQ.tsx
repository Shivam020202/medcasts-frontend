import React, { useState } from 'react';
import { ChevronDown, ChevronUp, HelpCircle } from 'lucide-react';
import PopupForm from './PopupForm';

const FAQ = () => {
  const [activeQuestion, setActiveQuestion] = useState<number | null>(null);
  const [showPopup, setShowPopup] = useState(false);

  const faqs = [
    {
      question: "Do you accept insurance?",
      answer: "Yes, we accept most major insurance plans including Medicare, Medicaid, and private insurance. We recommend contacting your insurance provider to verify coverage for mental health services. Our staff can also help verify your benefits and explain your coverage options."
    },
    {
      question: "How does TMS therapy work?",
      answer: "Transcranial Magnetic Stimulation (TMS) is a non-invasive treatment that uses magnetic fields to stimulate nerve cells in the brain. It's FDA-approved for treatment-resistant depression and is performed in our office. The treatment typically involves daily sessions over 4-6 weeks, with each session lasting about 30-40 minutes."
    },
    {
      question: "What should I expect during my first appointment?",
      answer: "Your first appointment will be a comprehensive psychiatric evaluation lasting 60-90 minutes. We'll discuss your medical history, current symptoms, previous treatments, and develop a personalized treatment plan. Please bring a list of current medications, insurance information, and any relevant medical records."
    },
    {
      question: "How quickly can I get an appointment?",
      answer: "We strive to provide timely access to care. For urgent situations, we often have same-day or next-day availability. For routine appointments, we typically can schedule within 1-2 weeks. We also offer telehealth appointments for added convenience and faster access."
    },
    {
      question: "Do you offer telehealth services?",
      answer: "Yes, we offer secure telehealth appointments for many of our services, including psychiatric evaluations, medication management, and therapy sessions. Telehealth provides convenient access to care from the comfort of your home while maintaining the same quality of service as in-person visits."
    }
  ];

  const toggleQuestion = (index: number) => {
    setActiveQuestion(activeQuestion === index ? null : index);
  };

  return (
    <section id="faq" className="py-12 md:py-16 bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 md:mb-12">
          <div className="flex justify-center mb-6">
            <div className="bg-[#FF6606] rounded-full p-4">
              <HelpCircle className="w-8 h-8 text-white" />
            </div>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-[#604C45] mb-4 md:mb-6">
            Frequently Asked <span className="text-[#FF6606]">Questions</span>
          </h2>
          <p className="text-lg md:text-xl text-gray-600">
            Find answers to common questions about our services and what to expect.
          </p>
        </div>

        <div className="space-y-3 md:space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-white rounded-lg md:rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg"
            >
              <button
                onClick={() => toggleQuestion(index)}
                className="w-full px-4 md:px-6 py-4 md:py-6 text-left flex justify-between items-center hover:bg-gray-50 transition-colors"
              >
                <h3 className="text-base md:text-lg font-semibold text-[#604C45] pr-4">
                  {faq.question}
                </h3>
                <div className="flex-shrink-0">
                  {activeQuestion === index ? (
                    <ChevronUp className="w-6 h-6 text-[#FF6606]" />
                  ) : (
                    <ChevronDown className="w-6 h-6 text-[#FF6606]" />
                  )}
                </div>
              </button>
              
              {activeQuestion === index && (
                <div className="px-4 md:px-6 pb-4 md:pb-6">
                  <div className="border-t border-gray-200 pt-4">
                    <p className="text-sm md:text-base text-gray-600 leading-relaxed">
                      {faq.answer}
                    </p>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-600 mb-6">
            Still have questions? We're here to help.
          </p>
          <button 
            onClick={() => setShowPopup(true)}
            className="bg-[#FF6606] text-white px-8 py-3 rounded-lg hover:bg-[#88A36C] transition-all duration-300 transform hover:scale-105 font-semibold"
          >
            Contact Us Today
          </button>
        </div>
      </div>
      
      <PopupForm 
        isOpen={showPopup} 
        onClose={() => setShowPopup(false)}
        title="Contact Us Today"
      />
    </section>
  );
};

export default FAQ;