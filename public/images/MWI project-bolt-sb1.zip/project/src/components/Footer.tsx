import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-[#604C45] text-white py-6 md:py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          {/* Logo */}
          <div className="mb-4 md:mb-6">
            <img 
              src="/public/MWI-Health-Gradient-Transparent.webp" 
              alt="MWI Health" 
              className="h-12 md:h-16 w-auto mx-auto filter brightness-0 invert"
            />
          </div>

          {/* Tagline */}
          <div className="mb-4 md:mb-6">
            <h3 className="text-xl md:text-2xl font-bold text-[#FF6606]">
              On the Right Path
            </h3>
          </div>

          {/* Copyright */}
          <div className="border-t border-gray-600 pt-4 md:pt-6">
            <p className="text-gray-400 text-xs md:text-sm">
              © {new Date().getFullYear()} MWI Health. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;