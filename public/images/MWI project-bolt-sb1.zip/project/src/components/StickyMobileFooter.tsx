import React from 'react';
import { Home, Phone, Calendar } from 'lucide-react';

const StickyMobileFooter = () => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleCallNow = () => {
    window.location.href = 'tel:+16055732000';
  };

  const handleBookAppointment = () => {
    const element = document.getElementById('hero');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      // Focus on the form after scrolling
      setTimeout(() => {
        const nameInput = document.querySelector('#fullName') as HTMLInputElement;
        if (nameInput) {
          nameInput.focus();
        }
      }, 500);
    }
  };

  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-40 md:hidden">
      <div className="grid grid-cols-3 h-16">
        {/* Home */}
        <button
          onClick={() => scrollToSection('hero')}
          className="flex flex-col items-center justify-center space-y-1 hover:bg-gray-50 transition-colors"
        >
          <Home className="w-5 h-5 text-[#604C45]" />
          <span className="text-xs text-[#604C45] font-medium">Home</span>
        </button>

        {/* Call Now */}
        <button
          onClick={handleCallNow}
          className="flex flex-col items-center justify-center space-y-1 hover:bg-gray-50 transition-colors"
        >
          <Phone className="w-5 h-5 text-[#FF6606]" />
          <span className="text-xs text-[#FF6606] font-medium">Call Now</span>
        </button>

        {/* Book Appointment */}
        <button
          onClick={handleBookAppointment}
          className="flex flex-col items-center justify-center space-y-1 hover:bg-gray-50 transition-colors"
        >
          <Calendar className="w-5 h-5 text-[#88A36C]" />
          <span className="text-xs text-[#88A36C] font-medium">Book Appt.</span>
        </button>
      </div>
    </div>
  );
};

export default StickyMobileFooter;