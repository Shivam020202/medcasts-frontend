import React, { useEffect, useRef } from 'react';
import { Award, Clock, Shield, Users } from 'lucide-react';

const WhyChooseUs = () => {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in-up');
          }
        });
      },
      { threshold: 0.1 }
    );

    const cards = sectionRef.current?.querySelectorAll('.fade-card');
    cards?.forEach((card) => observer.observe(card));

    return () => observer.disconnect();
  }, []);

  const features = [
    {
      icon: <Award className="w-12 h-12" />,
      title: "Research-Based Treatments",
      description: "We use only evidence-based therapies and cutting-edge treatments backed by scientific research to ensure the best outcomes for our patients."
    },
    {
      icon: <Clock className="w-12 h-12" />,
      title: "Immediate Availability",
      description: "Quick access to mental health care when you need it most. We offer flexible scheduling and urgent appointments for crisis situations."
    },
    {
      icon: <Shield className="w-12 h-12" />,
      title: "Insurance Accepted",
      description: "We work with most major insurance providers to make quality mental health care accessible and affordable for everyone."
    },
    {
      icon: <Users className="w-12 h-12" />,
      title: "Expert Team",
      description: "Our board-certified psychiatrists and licensed therapists bring decades of combined experience in treating complex mental health conditions."
    }
  ];

  return (
    <section id="why-choose-us" ref={sectionRef} className="py-12 md:py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 md:mb-12">
          <h2 className="text-4xl lg:text-5xl font-bold text-[#604C45] mb-6">
            Why Choose <span className="text-[#FF6606]">MWI Health</span>
          </h2>
          <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
            We're committed to providing exceptional mental health care with a focus on innovation, accessibility, and personalized treatment approaches.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="fade-card opacity-0 bg-gray-50 rounded-xl p-6 md:p-8 text-center hover:bg-white hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <div className="text-[#FF6606] mb-4 md:mb-6 flex justify-center">
                {feature.icon}
              </div>
              <h3 className="text-lg md:text-xl font-bold text-[#604C45] mb-3 md:mb-4">
                {feature.title}
              </h3>
              <p className="text-sm md:text-base text-gray-600 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      <style jsx>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-fade-in-up {
          animation: fadeInUp 0.6s ease-out forwards;
        }
      `}</style>
    </section>
  );
};

export default WhyChooseUs;