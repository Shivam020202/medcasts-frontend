import React from 'react';
import { Target } from 'lucide-react';

const Vision = () => {
  return (
    <section className="py-12 md:py-16 bg-gradient-to-r from-[#FF6606] to-[#88A36C]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center text-white">
          <div className="flex justify-center mb-6 md:mb-8">
            <div className="bg-white/20 rounded-full p-6">
              <Target className="w-16 h-16 text-white" />
            </div>
          </div>
          
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 md:mb-6">
            Our Vision
          </h2>
          
          <div className="max-w-4xl mx-auto">
            <h3 className="text-xl md:text-2xl font-semibold mb-4 md:mb-6 opacity-90">
              On the Right Path
            </h3>
            <p className="text-lg md:text-xl leading-relaxed opacity-90">
              Finding innovative ways to improve lives through compassionate, evidence-based mental health care. 
              We believe everyone deserves access to quality mental health services that promote healing, 
              growth, and lasting wellness.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Vision;