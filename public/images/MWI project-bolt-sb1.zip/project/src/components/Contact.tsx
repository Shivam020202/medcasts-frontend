import React, { useState } from 'react';
import { Phone, Mail, MapPin, Clock, Send } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
    setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <section id="contact" className="py-12 md:py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8 md:mb-12">
          <h2 className="text-4xl lg:text-5xl font-bold text-[#604C45] mb-6">
            Contact <span className="text-[#FF6606]">Us</span>
          </h2>
          <p className="text-lg md:text-xl text-gray-600 max-w-3xl mx-auto">
            Ready to take the first step? Get in touch with us today to schedule your consultation or learn more about our services.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 md:gap-12">
          {/* Contact Information & Form */}
          <div className="space-y-6 md:space-y-8">
            {/* Contact Info */}
            <div className="bg-gray-50 rounded-xl p-6 md:p-8">
              <h3 className="text-2xl font-bold text-[#604C45] mb-6">Get in Touch</h3>
              
              <div className="space-y-4 md:space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-[#FF6606] rounded-full p-3">
                    <Phone className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="text-sm md:text-base font-semibold text-[#604C45] mb-2">Phone Numbers</h4>
                    <p className="text-sm md:text-base text-gray-600">Sioux Falls: (605) 573-2000</p>
                    <p className="text-sm md:text-base text-gray-600">West Des Moines: (515) 500-6082</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-[#88A36C] rounded-full p-3">
                    <Mail className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="text-sm md:text-base font-semibold text-[#604C45] mb-2">Email Addresses</h4>
                    <p className="text-sm md:text-base text-gray-600">office@mwihealth.org</p>
                    <p className="text-sm md:text-base text-gray-600">intake@mwihealth.org</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="bg-[#FF6606] rounded-full p-3">
                    <Clock className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h4 className="text-sm md:text-base font-semibold text-[#604C45] mb-2">Office Hours</h4>
                    <p className="text-sm md:text-base text-gray-600">Monday - Friday: 8:00 AM - 5:00 PM</p>
                    <p className="text-sm md:text-base text-gray-600">Saturday: 9:00 AM - 1:00 PM</p>
                    <p className="text-sm md:text-base text-gray-600">Sunday: Closed</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Form */}
            <div className="bg-white border border-gray-200 rounded-xl p-6 md:p-8">
              <h3 className="text-2xl font-bold text-[#604C45] mb-6">Send us a Message</h3>
              
              <form onSubmit={handleSubmit} className="space-y-4 md:space-y-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="name" className="block text-xs md:text-sm font-medium text-[#604C45] mb-2">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6606] focus:border-transparent transition-all duration-200"
                      placeholder="Your full name"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-xs md:text-sm font-medium text-[#604C45] mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6606] focus:border-transparent transition-all duration-200"
                      placeholder="your.email@example.com"
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label htmlFor="phone" className="block text-xs md:text-sm font-medium text-[#604C45] mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6606] focus:border-transparent transition-all duration-200"
                      placeholder="(555) 123-4567"
                    />
                  </div>
                  <div>
                    <label htmlFor="subject" className="block text-xs md:text-sm font-medium text-[#604C45] mb-2">
                      Subject *
                    </label>
                    <select
                      id="subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6606] focus:border-transparent transition-all duration-200"
                    >
                      <option value="">Select a subject</option>
                      <option value="consultation">Schedule Consultation</option>
                      <option value="services">Services Inquiry</option>
                      <option value="insurance">Insurance Questions</option>
                      <option value="appointment">Appointment Request</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="message" className="block text-xs md:text-sm font-medium text-[#604C45] mb-2">
                    Message *
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    rows={4}
                    className="w-full px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#FF6606] focus:border-transparent transition-all duration-200 resize-vertical"
                    placeholder="Please describe how we can help you..."
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="w-full bg-[#FF6606] text-white py-3 md:py-4 rounded-lg hover:bg-[#88A36C] transition-all duration-300 transform hover:scale-105 font-semibold text-base md:text-lg flex items-center justify-center gap-2"
                >
                  <Send className="w-5 h-5" />
                  Send Message
                </button>
              </form>

              {showSuccess && (
                <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-green-800 text-center font-medium">
                    Thank you! Your message has been sent successfully. We'll get back to you soon.
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Interactive Maps */}
          <div className="space-y-6 md:space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-[#604C45] mb-6">Our Locations</h3>
              
              {/* Sioux Falls Map */}
              <div className="bg-white border border-gray-200 rounded-xl overflow-hidden mb-6 md:mb-8">
                <div className="p-6 bg-gray-50 border-b border-gray-200">
                  <div className="flex items-center gap-3 mb-2">
                    <MapPin className="w-5 h-5 text-[#FF6606]" />
                    <h4 className="text-lg md:text-xl font-semibold text-[#604C45]">Sioux Falls</h4>
                  </div>
                  <p className="text-sm md:text-base text-gray-600">4308 S Arway Drive, Sioux Falls, SD, 57106</p>
                  <p className="text-sm md:text-base text-gray-600">Phone: (605) 573-2000</p>
                </div>
                <div className="h-48 md:h-64">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2893.825893976978!2d-96.77443691578543!3d43.50596748746351!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x878a5907e4e8f351%3A0x1f18c398bc3a644e!2sMWI%20Health%20-%20Sioux%20Falls!5e0!3m2!1sen!2sin!4v1752144911206!5m2!1sen!2sin"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                  ></iframe>
                </div>
              </div>

              {/* West Des Moines Map */}
              <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
                <div className="p-6 bg-gray-50 border-b border-gray-200">
                  <div className="flex items-center gap-3 mb-2">
                    <MapPin className="w-5 h-5 text-[#FF6606]" />
                    <h4 className="text-lg md:text-xl font-semibold text-[#604C45]">West Des Moines</h4>
                  </div>
                  <p className="text-sm md:text-base text-gray-600">3737 Woodland Ave, Ste 410, West Des Moines, IA 50266</p>
                  <p className="text-sm md:text-base text-gray-600">Phone: (515) 500-6082</p>
                </div>
                <div className="h-48 md:h-64">
                  <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2984.062576095623!2d-93.75790782445529!3d41.58952898343311!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x87ec211d99704fc5%3A0x70f4249a9f0ca6e7!2sMWI%20Health%20-%20West%20Des%20Moines!5e0!3m2!1sen!2sin!4v1752144857892!5m2!1sen!2sin"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                  ></iframe>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;